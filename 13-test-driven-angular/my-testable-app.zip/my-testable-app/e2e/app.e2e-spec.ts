import { NgDemoPage } from './app.po';

describe('ng-cli-tdd App', () => {
  let page: NgDemoPage;

  beforeEach(() => {
    page = new NgDemoPage();
  });

  //Test nav and footer
  /*it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });*/
});
